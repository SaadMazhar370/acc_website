<?php
/**
 * FAQ Loop Start
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package Edumall
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;
?>
<ul class="edumall-faqs">
