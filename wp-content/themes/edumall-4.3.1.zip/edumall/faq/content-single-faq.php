<?php
/**
 * The template for displaying faq content in the single-faq.php template
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package Edumall
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;
?>


<?php the_content(); ?>
