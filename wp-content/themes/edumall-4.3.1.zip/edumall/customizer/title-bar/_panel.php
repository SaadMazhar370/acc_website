<?php
$panel    = 'title_bar';
$priority = 1;

Edumall_Kirki::add_section( 'title_bar', array(
	'title'    => esc_html__( 'General', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_01', array(
	'title'    => esc_html__( 'Style 01', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_02', array(
	'title'    => esc_html__( 'Style 02', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_03', array(
	'title'    => esc_html__( 'Style 03', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_04', array(
	'title'    => esc_html__( 'Style 04', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_05', array(
	'title'    => esc_html__( 'Style 05', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_06', array(
	'title'    => esc_html__( 'Style 06', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_07', array(
	'title'    => esc_html__( 'Style 07', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );

Edumall_Kirki::add_section( 'title_bar_08', array(
	'title'    => esc_html__( 'Style 08', 'edumall' ),
	'panel'    => $panel,
	'priority' => $priority++,
) );
