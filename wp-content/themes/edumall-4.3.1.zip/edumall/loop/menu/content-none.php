<ul class="children course-list no-courses">
	<li>
		<?php esc_html_e( 'There is no courses found.', 'edumall' ); ?>
	</li>
</ul>
