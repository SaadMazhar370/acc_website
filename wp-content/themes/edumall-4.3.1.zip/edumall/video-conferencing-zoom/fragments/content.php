<?php
/**
 * @author Deepen.
 * @created_on 11/20/19
 */
?>

<div class="deepn-zvc-single-description">
	<?php the_content(); ?>
</div>
