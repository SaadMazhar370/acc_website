<div id="page-title-bar" <?php Edumall_Title_Bar::instance()->the_wrapper_class(); ?>>
	<div class="page-title-bar-inner">
		<div class="page-title-bar-bg"></div>

		<?php edumall_load_template( 'breadcrumb' ); ?>
	</div>
</div>
