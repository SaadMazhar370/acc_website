<div class="page-footer elementor-footer" id="page-footer">
	<?php tm_addons_do_location( 'tm_footer' ); ?>
</div>
