<div class="page-footer elementor-footer" id="page-footer">
	<?php elementor_theme_do_location( 'footer' ); ?>
</div>
