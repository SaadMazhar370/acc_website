<div id="page-navigation" <?php Edumall::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Edumall::menu_primary( array(
			'extra_class' => 'sm-vertical',
		) ); ?>
	</nav>
</div>
