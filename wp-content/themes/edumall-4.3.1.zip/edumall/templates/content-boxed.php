<?php
/**
 * Template Name: Content Boxed
 *
 * @link      https://codex.wordpress.org/Template_Hierarchy
 *
 * @package   Edumall
 * @since     2.7.0
 * @version   2.7.0
 */
get_header();

edumall_load_template( 'page/content-single' );

get_footer();
