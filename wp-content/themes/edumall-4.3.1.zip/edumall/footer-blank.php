<?php
/**
 * The blank footer.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Edumall
 * @since   1.0
 */

?>
</div><!-- /.content-wrapper -->
</div><!-- /.site -->
<?php wp_footer(); ?>
</body>
</html>
