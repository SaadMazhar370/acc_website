<?php
/**
 * E-mail template footer
 *
 * @since 2.0.0
 *
 * @package TutorPro
 * @subpackage Templates\Email
 * @author Themeum <support@themeum.com>
 */

?>
<div class="tutor-email-footer">
	<div class="tutor-email-footer-text">
		<div data-source="email-footer-text">{footer_text}</div>
	</div>
</div>
