<div style="margin-bottom: 30px">
	<h6 data-source="email-heading" class="tutor-email-heading">{email_heading}</h6>
</div>

<div class="tutor-greetings-content">
	<p class="tutor-email-greetings">
		<?php echo esc_html( '{user_name},' ); ?>
	</p>
	<div class="email-user-content" data-source="email-additional-message">{email_message}</div>
</div>
