<div class="tutor-course-complete-form-wrap">
    <a class="tutor-btn tutor-btn-primary tutor-btn-block" href="<?php echo esc_url( $classroom_url ); ?>">
        <?php esc_html_e( 'Start Course', 'tutor-pro' ); ?>
    </a>
</div>